===========
KSTATS
===========

Collect KVM Stats. Requires KVM hypervisors and SSH enabled as auth mechanism
on libvirt.
